﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp
{
    public partial class Employee2
    {
        public String dep;
        public int Salary;
    }
    internal class Partial3
    {
    }
}
