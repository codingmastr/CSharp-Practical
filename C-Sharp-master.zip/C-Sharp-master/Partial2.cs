﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp
{
    public partial class person
    {
        public void PrintFullName()
        {
            Console.WriteLine(this.fn + " " + this.ln);
        }
    }
    internal class Partial2
    {
    }
}
