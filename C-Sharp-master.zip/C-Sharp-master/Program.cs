﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp
{
    internal class Program
    {

        static void Main(string[] args)
        {
            Lab1 lab1 = new Lab1();
            //lab1.program1();
            //lab1.program2();
            //lab1.program3();
            //lab1.program4();
            //lab1.program5();
            //lab1.program6();
            //lab1.program7();
            //lab1.program8();
            //lab1.program9();
            //lab1.program10();
            Lab2 lab2 = new Lab2();
            //Console.WriteLine("Assignment 2: ");
            //lab2.Program1();
            //lab2.Program2();
            //lab2.Program3();
            //lab2.Program4();
            //lab2.Program5();
            //lab2.Program6();
            //lab2.Program7();
            //lab2.Program8();
            //lab2.Program9();
            //lab2.Program10();
            Lab3 lab3 = new Lab3();
            //lab3.Program1(); 
            //lab3.Program4();
            //lab3.Program6();
            //lab3.Program7();
            //lab3.Program8();
            /*lab3.Program9();
            Lab4 lab4 = new Lab4();
            lab4.Program1();
            lab4.Program2(); 
            lab4.Program3();
            lab4.Program4();
            lab4.Program5();
            lab4.Program7();
            */
            Lab5 lab5 = new Lab5();
            lab5.program1();
            lab5.program2();
            lab5.program3();
            lab5.program4();
            lab5.program5();
            lab5.Program6();
            Console.WriteLine();
        }
    }
}
