﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp
{
    public partial class person
    {
        public string fn;
        public string ln;
    }
    internal class Partial1
    {
    }
}
